﻿<?
// 1. 공통 인클루드 파일
include ("./head.php");

// 2. 상품 존재 검사
$data = sql_fetch("select * from m__item where i_idx = '".$_GET[i_idx]."'");
if(!$data[i_idx]){
    alert("존재하지 않는 상품입니다.");
}
?>




<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="keywords" content="" />
    <title>Home | E-Shopper</title>
    <link rel="stylesheet" type="text/css" href="css/bootie.css" />
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="/css/mat.css" />

    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->


<body>

<br/>
<br>
<br>
<br>


<div class="container">
<table class="table" style="border:0px;">
    <tr>
        <td align="center" valign="middle" style="font-zise:15px;font-weight:bold;">상품보기</td>
    </tr>
</table>
<br/>



<form name="itemForm" method="post" action="./cart_save.php" style="margin:0px;">
<!-- 3. 장바구니나 바로구매 버튼 클릭시 mode 의 값을 채워서 전달 -->
<input type="hidden" name="mode" value="">
<input type="hidden" name="page" value="<?=$_GET[page]?>">
<input type="hidden" name="i_idx" value="<?=$data[i_idx]?>">
<input type="hidden" name="price" value="<?=$data[i_price]?>">

<table class="table">
    <tr>
        <td align="center" valign="middle" style="font-zise:15px;font-weight:bold;background-color:#e4e4e4;">상품명</td>
        <td align="left" valign="middle"><?=$data[i_name]?></td>
    </tr>
    <tr>
        <td align="center" valign="middle" style="font-zise:15px;font-weight:bold;background-color:#e4e4e4;">상품가격</td>
        <td align="left" valign="middle"><?=$data[i_price]?></td>
    </tr>
    <tr>
        <td align="center" valign="middle" style="font-zise:15px;font-weight:bold;background-color:#e4e4e4;">상품설명</td>
        <td align="left" valign="middle" ><?=nl2Br($data[i_explain])?></td>
    </tr>
    <tr>
        <td align="center" valign="middle" style="font-zise:15px;font-weight:bold;background-color:#e4e4e4;">구매수량</td>
        <td align="left" valign="middle" ><input type="text" name="c_cnt" onChange="caluate_item();">개</td><!-- 4. 수량변경 시 체크 후 총가격값을 입력 -->
    </tr>
    <tr>
        <td align="center" valign="middle" style="font-zise:15px;font-weight:bold;background-color:#e4e4e4;">총가격</td>
        <td align="left" valign="middle" ><input type="text" name="c_price" value="0" readOnly>원</td>
    </tr>
    <!-- 5. 로그인 한 사람만 장바구니와 바로구매 버튼이 보기고 버튼 클릭시 cart_save함수로 검사 -->
    <tr>
        <td align="center" valign="middle" colspan="2">
        <?if($_SESSION[user_id]){?>
        <input type="button" value=" 장바구니 " onClick="cart_save('cart');"> 
        <input type="button" value=" 바로구매 " onClick="cart_save('direct');"> 
        <?}?>
        <input type="button" value=" 목록 " onClick="location.href='./index.php?page=<?=$_GET[page]?>';"></td>
    </tr>
</table>
</form>
<script>
// 수량 검사 밑 총 가격 만드는 함수
function caluate_item()
{
    var f = document.itemForm;
    var cnt_obj = f.c_cnt;    // 수량

    if(cnt_obj.value == ""){
        alert("구매수량을 입력해 주세요.");
        return false;
    }else{
        // 숫자인지 검사
        for (var i = 0; i < cnt_obj.value.length; i++){

            if (cnt_obj.value.charAt(i) < '0' || cnt_obj.value.charAt(i) > '9'){ 
                alert("구매수량을 숫자로 입력해 주세요.");
                return false;
            }
        }
    }

    // 수량과 가격을 곱해 총가격은 만듬
    var price = parseInt(f.price.value) * parseInt(cnt_obj.value);

    f.c_price.value = price;

    return true;
}

// 입력필드 검사함수
function cart_save(arg)
{
    // form 을 f 에 지정
    var f = document.itemForm;

    // 수량검사 후 장바구니담기인지 바로구매인지 값을 mode 에 저장 후 서브밋
    if(caluate_item()){
        f.mode.value = arg
        f.submit();
    }

}
</script>



 <br>
<br>
<br>
<br>
<br>
</div>


    <footer id="footer"><!--Footer-->
        <div class="footer-top">
            <div class="container">
                <div class="row">
                    <div class="col-sm-2">
                        <div class="companyinfo">
                            <h2><span>e</span>-shopper</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit,sed do eiusmod tempor</p>
                        </div>
                    </div>
                    <div class="col-sm-7">
                        <div class="col-sm-3">
                            <div class="video-gallery text-center">
                                <a href="#">
                                    <div class="iframe-img">
                                        <img src="images/home/iframe1.png" alt="" />
                                    </div>
                                    <div class="overlay-icon">
                                        <i class="fa fa-play-circle-o"></i>
                                    </div>
                                </a>
                                <p>Circle of Hands</p>
                                <h2>2018 11 05</h2>
                            </div>
                        </div>
                        
                        <div class="col-sm-3">
                            <div class="video-gallery text-center">
                                <a href="#">
                                    <div class="iframe-img">
                                        <img src="images/home/iframe2.png" alt="" />
                                    </div>
                                    <div class="overlay-icon">
                                        <i class="fa fa-play-circle-o"></i>
                                    </div>
                                </a>
                                <p>Circle of Hands</p>
                                <h2>2018 11 05</h2>
                            </div>
                        </div>
                        
                        <div class="col-sm-3">
                            <div class="video-gallery text-center">
                                <a href="#">
                                    <div class="iframe-img">
                                        <img src="images/home/iframe3.png" alt="" />
                                    </div>
                                    <div class="overlay-icon">
                                        <i class="fa fa-play-circle-o"></i>
                                    </div>
                                </a>
                                <p>Circle of Hands</p>
                                <h2>2018 11 05</h2>
                            </div>
                        </div>
                        
                        <div class="col-sm-3">
                            <div class="video-gallery text-center">
                                <a href="#">
                                    <div class="iframe-img">
                                        <img src="images/home/iframe4.png" alt="" />
                                    </div>
                                    <div class="overlay-icon">
                                        <i class="fa fa-play-circle-o"></i>
                                    </div>
                                </a>
                                <p>Circle of Hands</p>
                                <h2>2018 11 05</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="address">
                            <img src="images/home/map.png" alt="" />
                            <p>Seoul, South Korea</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="footer-widget">
            <div class="container">
                <div class="row">
                    <div class="col-sm-2">
                        <div class="single-widget">
                            <h2>Service</h2>
                            <ul class="nav nav-pills nav-stacked">
                                <li><a href="#">Online Help</a></li>
                                <li><a href="#">Contact Us</a></li>
                                <li><a href="#">Order Status</a></li>
                                <li><a href="#">Change Location</a></li>
                                <li><a href="#">FAQ’s</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-2">
                        <div class="single-widget">
                            <h2>Quock Shop</h2>
                            <ul class="nav nav-pills nav-stacked">
                                <li><a href="index.html">Main</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-2">
                        <div class="single-widget">
                            <h2>Policies</h2>
                            <ul class="nav nav-pills nav-stacked">
                                <li><a href="#">Terms of Use</a></li>
                                <li><a href="#">Privecy Policy</a></li>
                                <li><a href="#">Refund Policy</a></li>
                                <li><a href="#">Billing System</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-2">
                        <div class="single-widget">
                            <h2>About Shopper</h2>
                            <ul class="nav nav-pills nav-stacked">
                                <li><a href="#">Company Information</a></li>
                                <li><a href="#">Careers</a></li>
                                <li><a href="#">Store Location</a></li>
                                <li><a href="#">Affillate Program</a></li>
                                <li><a href="#">Copyright</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-3 col-sm-offset-1">
                        <div class="single-widget">
                            <h2>About Shopper</h2>
                            <form action="#" class="searchform">
                                <input type="text" placeholder="Your email address" />
                                <button type="submit" class="btn btn-default"><i class="fa fa-arrow-circle-o-right"></i></button>
                                <p>Get the most recent updates from <br />our site and be updated your self...</p>
                            </form>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <p class="pull-left">Copyright © SWU PBL 3BLOCKS</p>
                    <p class="pull-right">Designed by <span><a target="_blank" href="http://www.themeum.com">Wannie</a></span></p>
                </div>
            </div>
        </div>
        
    </footer><!--/Footer-->

  
    <script src="js/jquery-3.1.1.js"></script>
        <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/price-range.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>

</body>