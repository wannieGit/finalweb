<?
// 1. 공통 인클루드 파일
include ("./head.php");

// 2. 로그인한 회원은 뒤로 보내기
if($_SESSION[user_id]){
    alert("Already Login");
}
// 3. 입력 HTML 출력
?>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Login/Registration Form Transition</title>
  
  
  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Open+Sans'>

      <link rel="stylesheet" href="css/style.css">

  
</head>

<body>

<div class="cont">
 <form name="loginForm" method="post" action="./login_chk.php" style="margin:0px;">
  <div class="form sign-in">
    <h2>Welcome back,</h2>

    <label>
      <span>ID</span>
      <input type="text" name="m_id" />
    </label>
    <label>
      <span>Password</span>
      <input type="password" name="m_pass" />
    </label>


    <button type="button" class="submit" onClick="login_chk();">Sign In</button>
  </div>
 </form>

<script>
function login_chk()
{
    // 6.form 을 f 에 지정
    var f = document.loginForm;
    // 7.입력폼 검사
    if(f.m_id.value == ""){
        // 8.값이 없으면 경고창으로 메세지 출력 후 함수 종료
        alert("Input ID!");
        return false;    }

    if(f.m_pass.value == ""){
        alert("Input Password!");
        return false;
    }
    // 9.검사가 성공이면 form 을 submit 한다
    f.submit();
}
</script>


  <div class="sub-cont">
    <div class="img">
      <div class="img__text m--up">
        <h2>New here?</h2>
        <p>Sign up and discover great amount of new opportunities!</p>
      </div>
      <div class="img__text m--in">
        <h2>One of us?</h2>
        <p>If you already has an account, just sign in. We've missed you!</p>
      </div>
      <div class="img__btn">
        <span class="m--up">Sign Up</span>
        <span class="m--in">Sign In</span>
      </div>
    </div>


 <form name="registForm" method="post" action="./member_join_save.php" style="margin:0px;">
    <div class="form sign-up">
      <h2>Time to feel like home,</h2>
      <label>
        <span>ID</span>
        <input type="text" name="m_id" />
      </label>
      <label>
        <span>Name</span>
        <input type="text" name="m_name"/>
      </label>
      <label>
        <span>Password</span>
        <input type="password" name="m_pass"/>
      </label>
      <label>
        <span>Checking Password</span>
        <input type="password" name="m_pass2"/>
      </label>
      <button type="button" class="submit" onClick="member_save();">Sign Up</button>
    </div>
  </form>


<script>
// 5.입력필드 검사함수
function member_save()
{
    // 6.form 을 f 에 지정
    var f = document.registForm;

    // 7.입력폼 검사
    if(f.m_id.value == ""){
        // 8.값이 없으면 경고창으로 메세지 출력 후 함수 종료
        alert("Input ID");
        return false;
    }

    if(f.m_name.value == ""){
        alert("Input name");
        return false;
    }

    if(f.m_pass.value == ""){
        alert("Input password");
        return false;
    }

    if(f.m_pass.value != f.m_pass2.value){
        // 9.비밀번호와 확인이 서로 다르면 경고창으로 메세지 출력 후 함수 종료
        alert("check password");
        return false;
    }

    // 10.검사가 성공이면 form 을 submit 한다
    f.submit();

}
</script>

  </div>



</div>


  
  

    <script  src="js/index.js"></script>




</body>

</html>
