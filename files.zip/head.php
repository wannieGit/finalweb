<?
include "./lib.php";
?>
<html>
<head>
    <title>E-Shopper</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Home | E-Shopper</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->
<body>
             <header id="header"><!--header-->
		<div class="header_top"><!--header_top-->
			<div class="container">
				<div class="row">
					<div class="col-sm-6">
						<div class="contactinfo">
    <?
    // 1.�α��� ���ο� ���� ��� �޴��� �ٸ���
    if($_SESSION[user_idx]){
    ?>
							<ul class="nav nav-pills">
								<li><a href="index.php"> HOME </a></li>
								<li><a href="./cart.php"> Cart </a></li>
								<li><a href="./member.php">Purchase </a></li>
								<li><a href="../point.php"> Point </a></li>
								<li><a href="./order_list.php">Sell </a></li>
								<li><a href="./item_list.php">Management </a></li>
								<li><a href="./logout.php">Logout </a></li>
							</ul>
    <?}else{?>

							<ul class="nav nav-pills">
								<li><a href="index.php"> HOME </a></li>
								<li><a href="login.php">Register & Login </a></li>
							</ul>
    <?}?>
						</div>
					</div>
				</div>
			</div>
		</div><!--/header_top-->
	</header><!--/header-->
</body>
</html>