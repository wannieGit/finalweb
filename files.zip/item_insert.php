﻿<?
// 1. 공통 인클루드 파일
include ("./head.php");
// 2. 로그인 하지 않은 회원은 로그인 페이지로 보내기
if(!$_SESSION[user_id]){
    alert("로그인하셔야 이용이 가능합니다.", "./login.php");
}
// 3. 입력 HTML 출력
?>




<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="keywords" content="" />
    <title>Home | E-Shopper</title>
    <link rel="stylesheet" type="text/css" href="css/bootie.css" />
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/price-range.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="/css/mat.css" />

    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->


<body>

<br/>
<br>
<br>
<br>



<div class="container">
<table class="table" style="border:0px;">
    <tr>
        <td align="center" valign="middle" style="font-zise:15px;font-weight:bold;">상품관리 - 상품등록</td>
    </tr>
</table>
<br/>


<form name="itemForm" method="post" action="./item_save.php" style="margin:0px;">
<!-- 4. 등록이면 mode 의 값은 insert 수정이면 modify -->
<input type="hidden" name="mode" value="insert">
<table class="table">
    <tr>
        <td align="center" valign="middle" style="font-zise:15px;font-weight:bold;background-color:#e4e4e4;">상품명</td>
        <td align="left" valign="middle" ><input type="text" name="i_name"></td>
    </tr>
    <tr>
        <td align="center" valign="middle" style="font-zise:15px;font-weight:bold;background-color:#e4e4e4;">상품가격</td>
        <td align="left" valign="middle" "><input type="text" name="i_price">원</td>
    </tr>
    <tr>
        <td align="center" valign="middle" style="font-zise:15px;font-weight:bold;background-color:#e4e4e4;">상품설명</td>
        <td align="left" valign="middle"><textarea name="i_explain"></textarea></td>
    </tr>
    <!-- 5. 상품등록 버튼 클릭시 입력필드 검사 함수 item_save 실행 -->
    <tr>
        <td align="center" valign="middle" colspan="2"><input type="button" value=" 상품등록 " onClick="item_save();"> <input type="button" value=" 목록 " onClick="location.href='./item_list.php?page=<?=$_GET[page]?>';"></td>
    </tr>
</table>
</form>
<script>
// 6.입력필드 검사함수
function item_save()
{
    // 7.form 을 f 에 지정
    var f = document.itemForm;
    // 8.입력폼 검사
    if(f.i_name.value == ""){
        // 9.값이 없으면 경고창으로 메세지 출력 후 함수 종료
        alert("상품명을 입력해 주세요.");
        return false;
    }
    if(f.i_price.value == ""){
        alert("상품가격을 입력해 주세요.");
        return false;
    }else{
        // 10.숫자인지 검사
        for (var i = 0; i < f.i_price.value.length; i++){
            if (f.i_price.value.charAt(i) < '0' || f.i_price.value.charAt(i) > '9'){ 
                alert("상품가격은 숫자로 입력해 주세요.");
                return false;
            }
        }
    }
    if(f.i_explain.value == ""){
        alert("상품설명을 입력해 주세요.");
        return false;
    }
    // 11.검사가 성공이면 form 을 submit 한다
    f.submit();
}
</script>




 <br>
<br>
<br>
<br>
<br>
</div>


    <footer id="footer"><!--Footer-->
        <div class="footer-top">
            <div class="container">
                <div class="row">
                    <div class="col-sm-2">
                        <div class="companyinfo">
                            <h2><span>e</span>-shopper</h2>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit,sed do eiusmod tempor</p>
                        </div>
                    </div>
                    <div class="col-sm-7">
                        <div class="col-sm-3">
                            <div class="video-gallery text-center">
                                <a href="#">
                                    <div class="iframe-img">
                                        <img src="images/home/iframe1.png" alt="" />
                                    </div>
                                    <div class="overlay-icon">
                                        <i class="fa fa-play-circle-o"></i>
                                    </div>
                                </a>
                                <p>Circle of Hands</p>
                                <h2>2018 11 05</h2>
                            </div>
                        </div>
                        
                        <div class="col-sm-3">
                            <div class="video-gallery text-center">
                                <a href="#">
                                    <div class="iframe-img">
                                        <img src="images/home/iframe2.png" alt="" />
                                    </div>
                                    <div class="overlay-icon">
                                        <i class="fa fa-play-circle-o"></i>
                                    </div>
                                </a>
                                <p>Circle of Hands</p>
                                <h2>2018 11 05</h2>
                            </div>
                        </div>
                        
                        <div class="col-sm-3">
                            <div class="video-gallery text-center">
                                <a href="#">
                                    <div class="iframe-img">
                                        <img src="images/home/iframe3.png" alt="" />
                                    </div>
                                    <div class="overlay-icon">
                                        <i class="fa fa-play-circle-o"></i>
                                    </div>
                                </a>
                                <p>Circle of Hands</p>
                                <h2>2018 11 05</h2>
                            </div>
                        </div>
                        
                        <div class="col-sm-3">
                            <div class="video-gallery text-center">
                                <a href="#">
                                    <div class="iframe-img">
                                        <img src="images/home/iframe4.png" alt="" />
                                    </div>
                                    <div class="overlay-icon">
                                        <i class="fa fa-play-circle-o"></i>
                                    </div>
                                </a>
                                <p>Circle of Hands</p>
                                <h2>2018 11 05</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="address">
                            <img src="images/home/map.png" alt="" />
                            <p>Seoul, South Korea</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="footer-widget">
            <div class="container">
                <div class="row">
                    <div class="col-sm-2">
                        <div class="single-widget">
                            <h2>Service</h2>
                            <ul class="nav nav-pills nav-stacked">
                                <li><a href="#">Online Help</a></li>
                                <li><a href="#">Contact Us</a></li>
                                <li><a href="#">Order Status</a></li>
                                <li><a href="#">Change Location</a></li>
                                <li><a href="#">FAQ’s</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-2">
                        <div class="single-widget">
                            <h2>Quock Shop</h2>
                            <ul class="nav nav-pills nav-stacked">
                                <li><a href="index.html">Main</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-2">
                        <div class="single-widget">
                            <h2>Policies</h2>
                            <ul class="nav nav-pills nav-stacked">
                                <li><a href="#">Terms of Use</a></li>
                                <li><a href="#">Privecy Policy</a></li>
                                <li><a href="#">Refund Policy</a></li>
                                <li><a href="#">Billing System</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-2">
                        <div class="single-widget">
                            <h2>About Shopper</h2>
                            <ul class="nav nav-pills nav-stacked">
                                <li><a href="#">Company Information</a></li>
                                <li><a href="#">Careers</a></li>
                                <li><a href="#">Store Location</a></li>
                                <li><a href="#">Affillate Program</a></li>
                                <li><a href="#">Copyright</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-3 col-sm-offset-1">
                        <div class="single-widget">
                            <h2>About Shopper</h2>
                            <form action="#" class="searchform">
                                <input type="text" placeholder="Your email address" />
                                <button type="submit" class="btn btn-default"><i class="fa fa-arrow-circle-o-right"></i></button>
                                <p>Get the most recent updates from <br />our site and be updated your self...</p>
                            </form>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <p class="pull-left">Copyright © SWU PBL 3BLOCKS</p>
                    <p class="pull-right">Designed by <span><a target="_blank" href="http://www.themeum.com">Wannie</a></span></p>
                </div>
            </div>
        </div>
        
    </footer><!--/Footer-->

  
    <script src="js/jquery-3.1.1.js"></script>
        <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.scrollUp.min.js"></script>
    <script src="js/price-range.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/main.js"></script>

</body>